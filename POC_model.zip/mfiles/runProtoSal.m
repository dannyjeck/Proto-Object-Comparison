function [out] = runProtoSal(filename)
%Runs the proto-object based saliency algorithm
%
%inputs:
%filename - filename of image
%
%By Alexander Russell and Stefan Mihalas, Johns Hopkins Univeristy, 2012

fprintf('Start Proto-Object Saliency')
%generate parameter structure
params = makeDefaultParams;
%load and normalize image
im = normalizeImage(im2double(imread(filename)));
%generate feature channels
img = generateChannels(im,params);
%generate border ownership structures
[b1Pyr b2Pyr]  = makeBorderOwnership(img,params);        
% out.b1Pyr = b1Pyr;
% out.b2Pyr = b2Pyr;
%generate grouping pyramids
gPyr = makeGrouping(b1Pyr,b2Pyr,params);
%normalize grouping pyramids and combine into final saliency map
h = ittiNorm(gPyr,4);

sumsal = zeros(size(h.data));
gPyr2 = gPyr;
for j = 1:length(gPyr)
    for k = 1:length(gPyr{j}.subtype)
        gPyr2{j}.subtype{k} = gPyr{j}.subtype{k};
        for l = 1:length(gPyr{j}.subtype{k})
            sumsal = sumsal + 4^l*imresize(gPyr{j}.subtype{k}(l).data,size(h.data));
        end
    end
end

out.gPyr = gPyr;
out.sumsal = sumsal;
out.Sal = h.data;
out.im = im;

fprintf('\nDone\n')
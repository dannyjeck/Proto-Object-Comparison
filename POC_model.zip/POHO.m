function [Poho_sal2, out, Xsel, Ysel, Rsel, strsel, Q] = POHO(filename,K,alpha,display)

    %% Parameters
    if nargin<4
        display = 1;
    end
    if nargin<2
        K=1;
    end
    if nargin<3
        alpha = 0;
    end
    if nargin<1 %defaults
        filename = './img/squares2.png';
    end
    % % imshow(im)
    Nbins = 9;
    Nprotomax = 18000;
    min_R_inx = 4;
    
    
    %% Run Alex's model on input - get out gPyr
    [out] = runProtoSal(filename);
    im = out.im;
    gPyr = out.gPyr;


    %% Threshold/merging operation to determine regions of interest

    [X,Y,R,str] = ProtoThresh2(gPyr); 
    %str represents the strength of the proto-object representation.

    %% 
    sel = true(size(X));
    R_list = unique(R);
%     for k = 1:length(R_list)
%         thresh = 0;%quantile(str(R==R_list(k)),0.1);
%         sel(R==R_list(k) & str<=thresh) = false;
%     end


    sel = sel & R>R_list(min_R_inx) & R<=R_list(end-1);
%     sel = false(size(sel)); sel([1026694 1025482 1025684]) = true;
    Xsel = X(sel);
    Ysel = Y(sel);
    Rsel = R(sel);
    strsel = str(sel);


    % sel = sel & str>max(str)/10;


    % figure(1); imshow(im); colormap gray; hold all;vl_plotframe([X(sel),Y(sel),4*R(sel)]'); hold off;
%     figure(1); imshow(imrotate(im,-90)); colormap gray; hold all;vl_plotframe([size(im,1)-Ysel,Xsel,Rsel]'); hold off;

    %%
    % im2 = zeros(size(sum(im,3)));
    % for k = 1:length(X);
    %     x = X(k);y = Y(k); r = R(k);
    %     ylst = y-r:y+r;
    %     ylst = ylst(ylst>0 & ylst<=size(im2,1));
    %     xlst = x-r:x+r;
    %     xlst = xlst(xlst>0 & xlst<=size(im2,2));
    %     s = str(k);
    %     
    %     im2(ylst,xlst) = im2(ylst,xlst)+s;
    % end
    % figure(2); imagesc(imrotate(sum(im,3),-90)); colormap gray; hold all;
    % figure(3); imagesc(imrotate(im2,-90));

    %% Compute Higher Order Feature space 

    if display; disp('Computing Higher-Order Feature Space'); end
    
    Nfeat = HigherFeat();
    Nproto = length(Xsel);
    
    if Nproto>Nprotomax
        [str_tmp, sortvec] = sort(strsel,'descend');
        strsel = str_tmp(1:Nprotomax);
        Xsel = Xsel(sortvec(1:Nprotomax));
        Ysel = Ysel(sortvec(1:Nprotomax));
        Rsel = Rsel(sortvec(1:Nprotomax));
        warning(['too many proto objects above threshold: ' num2str(Nproto)]);
        Nproto = Nprotomax;
    end
    
    P = NaN(Nbins,Nfeat,Nproto);
    C = makecform('srgb2lab');
    im_lab = applycform(im,C);
    
    
%     cd ./POHO_mfiles/    
    for k = 1:Nproto
        %display update
        if (mod(k,1000)==0 && display); disp([num2str(k) ' out of ' num2str(length(Xsel)) ' proto-objects complete']); end
        
        P(:,:,k) = HigherFeat(Xsel(k),Ysel(k),Rsel(k),strsel(k),im_lab,Nbins);
    end
%     cd ..
    
    %% Competition
    
    P2 = P(:,1:end,:);
    Q = Competition(P2,K,alpha);
    
    
    %% Salience out
    if display; disp('Computing Salience Map'); end
    proto_sal = squeeze(sum(sum(Q,1),2));

    Poho_sal = genSalMap(Xsel,Ysel,Rsel,proto_sal,size(im));
    
    imsize = [size(im,1) size(im,2)];
    sumsal = imresize(out.sumsal,imsize);
    
    sumsal2 = genSalMap(Xsel,Ysel,Rsel,strsel,size(im));
    out.Ssal = sumsal2;
    
    sumsal = sumsal/max(sumsal(:));
    Poho_sal = Poho_sal/max(Poho_sal(:));
    
    Poho_sal2 = (1-alpha)*Poho_sal+alpha*sumsal;
    
    Poho_sal2 = Poho_sal2/sum(Poho_sal2(:));
    
    % Plot output
    [b, a] = find(Poho_sal== max(Poho_sal(:)),1);

    if display
        figure(1);
        subplot(221); imshow(imrotate(im,-90)); title(['Input: ' filename]);
        hold all; plot(size(im,1)-b,a,'og'); hold off;

    %     subplot(224); 
    %     imshow(imrotate(im,-90));hold all;vl_plotframe([size(im,1)-Ysel,Xsel,Rsel]'); hold off;
    %     title('Proto-objects');

        subplot(223);
        imagesc(imrotate(Poho_sal2,-90)); colormap('gray')
        title('POHO+contrast');

        subplot(222)
        imagesc(imrotate(Poho_sal,-90)); colormap('gray')
        title('POHO model');

        hold all; plot(size(im,1)-b,a,'ob'); hold off;

        subplot(224)
        imagesc(imrotate(out.sumsal,-90)); colormap('gray')
        title('G cell sum');
        [b, a] = find(out.sumsal== max(out.sumsal(:)),1);
        hold all; plot(size(im,1)-b,a,'ob'); hold off;

        %%
        [b, a] = find(Poho_sal== max(Poho_sal(:)),1);

        figure(2);
        imshow(imrotate(im,-90)); title(['Input: ' filename]);
        hold all; plot(size(im,1)-b,a,'og'); hold off;

        figure(3);
        imagesc(imrotate(Poho_sal,-90)); colormap('gray')
        title('POHO model');
        hold all; plot(size(im,1)-b,a,'ob'); hold off;
    end
end
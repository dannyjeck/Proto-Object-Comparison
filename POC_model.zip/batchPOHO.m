% Nimg = 1; %judd
 Nimg = 30; %squares
%Nimg = 100; %interest
% Nimg = 28; %hard salience


Poho_sal_all = cell(Nimg,1);
russ_sal_all = cell(Nimg,1);
russ_sumsal_all = cell(Nimg,1);
russ_sumsal2_all = cell(Nimg,1);

% for k = 1:Nimg %use this for resizing the hard-salience-images
%     Poho_sal_all{k} = zeros(768,1024);
%     russ_sal_all{k} = zeros(768,1024);
%     russ_sumsal_all{k} = zeros(768,1024);
%     
%     im = imread(['~/Dropbox/hard-salience-images/' num2str(k) '.jpg']);
%     im_r = imresize(im,[768 NaN]);
%     imwrite(im_r,['~/Dropbox/hard-salience-images/' num2str(k) '_resize.jpg']);
% end



%%
% matlabpool(4)

for k = 1:Nimg
     f = ['./img/squares' num2str(k) '.png'];
%    f = ['~/Documents/MATLAB/Jamal_salience/interest_images/image' num2str(k-1) '.jpg'];
%     f = ['~/Documents/MATLAB/salObject/datasets/imgs/judd/' num2str(k) '.jpg'];
%     f = ['~/Dropbox/hard-salience-images/' num2str(k) '_resize2.jpg'];
    disp(['Processing image ' num2str(k)]);
    
    %parameters
    alpha = 0;
    display = false;
    K = 1;
    
    %run POHO
    tic
    [Poho_sal, russ_sal, Xsel, Ysel, Rsel, strsel, Q] = POHO(f,K,alpha,display);
    toc
    
    %Manage outputs
    Poho_sal_all{k} = Poho_sal;
    russ_sal_all{k} = imresize(russ_sal.Sal,[size(Poho_sal,1) size(Poho_sal,2)]);
    russ_sumsal_all{k} = imresize(russ_sal.sumsal,[size(Poho_sal,1) size(Poho_sal,2)]);
    russ_sumsal2_all{k} = russ_sal.Ssal; %Ouptut when normalization is skipped
%      pause;
%     figure(1)
%     title(num2str(k));
end

clear russ_sal;
save Poho_output0.13.mat;
% keyboard;
%%

for k = [1:5 21:25]
    figure(4);
%     subplot(121);
%     f = ['./img/squares' num2str(k) '.png'];
%     im = imrotate(imread(f),-90);
%     imshow(im)
%     subplot(122);
    imagesc(imrotate(Poho_sal_all{k}-Poho_sal_all{k+5},-90))
    pause;
end
%%
load fixation_maps.mat;

% load russmaps.mat;
% load Poho_output_K0.7_greyblack.mat;

%%
% CB = zeros(size(fixmaps{1}));
% for k = 1:48
%     CB = CB + fixmaps{k};
% end
% CB = CB/48;

R_all_poho = zeros(Nimg,1);
R_all_russ = zeros(Nimg,1);
R_all_sumsal = zeros(Nimg,1);
R_all_pohoS = zeros(Nimg,1); %POHO without normalization comparison
for k = 1:Nimg
%     f = ['./img/squares' num2str(k) '.png'];
%     im = imrotate(imread(f),-90);
%     Poho_sal = imrotate(Poho_sal_all{k},-90);
%     fixmap = imresize(fixmaps{k-30},size(Poho_sal));
%     russ_sal = imrotate(imresize(russ_sal_all{k},size(Poho_sal)),-90);
%     russ_sumsal = imrotate(imresize(russ_sumsal_all{k},size(Poho_sal)),-90);
    disp(k)
    f = ['~/Documents/MATLAB/Jamal_salience/interest_images/image' num2str(k-1) '.jpg'];
    im = imread(f);
%     Poho_sal = Poho_sal_all{k};
%     fixmap = imresize(fixmaps{k},size(Poho_sal));
%     russ_sal = russ_sal_all{k};
%     russ_sumsal = russ_sumsal_all{k};
    
    Poho_sal = downsize_map(Poho_sal_all{k},40); %output is 480x640 instead of 768x1024
    fixmap = downsize_map(fixmaps{k},64);
    russ_sal = downsize_map(russ_sal_all{k},40);
    russ_sumsal = downsize_map(russ_sumsal_all{k},40);
    pohoS_sal = downsize_map(russ_sumsal2_all{k},40);
    
    
    R = corrcoef(fixmap(:),Poho_sal(:));
    R_all_poho(k) = R(2,1);
    R = corrcoef(fixmap(:),russ_sal(:));
    R_all_russ(k) = R(2,1);
    R = corrcoef(fixmap(:),pohoS_sal(:));
    R_all_pohoS(k) = R(2,1);
    
    R = corrcoef(fixmap(:),russ_sumsal(:));
    R_all_sumsal(k) = R(2,1);
    
    figure(1);
    subplot(221);
    imshow(im);
    title(['Image ' num2str(k)]);
    
    subplot(222);
    imagesc(fixmap);
    title('Fixation Map'); colormap('gray')
    
    
    
    subplot(223);
    imagesc(pohoS_sal);

    title(['Russell et al. Map; R = ' num2str(R_all_pohoS(k))]);colormap('gray')

    
    subplot(224);
    imagesc(Poho_sal)
    title(['POC Map; R = ' num2str(R_all_poho(k))]);colormap('gray')
    
%     subplot(236);
%     imagesc(russ_sumsal)
%     title(['POC without comp; R = ' num2str(R_all_sumsal(k))]);colormap('gray')
    
    boldify
%     pause
end

%% Show output on squares
% for k = 1:30
%     f = ['./img/squares' num2str(k) '.png'];
%     im = imrotate(imread(f),-90);
%     Poho_sal = imrotate(Poho_sal_all{k},-90);
%     russ_sal = imrotate(imresize(russ_sal_all{k},size(Poho_sal)),-90);
% 
%     figure(1)
%     subplot(121); imshow(im);
%     subplot(122); imagesc(Poho_sal);colormap('gray')
%     pause
% end
%%
% for k = 1:100
%     f = ['~/Documents/MATLAB/Jamal_salience/interest_images/image' num2str(k-1) '.jpg'];
%
%     figure(1);
%     subplot(221);
%     imshow(f); title(f);
%     subplot(222);
%     imagesc(russ_sal_all{k});title('Russell Sal');
%     subplot(223)
%     imagesc(russ_sumsal_all{k}); title('G cell sum');
%     subplot(224);
%     imagesc(fixmaps{k}); title('Fixations');
% 
%     pause
% end

%%
for k = 1:28
    f = ['~/Dropbox/hard-salience-images/' num2str(k) '_resize.jpg'];
    russ_sal = imresize(russ_sal_all{k}/sum(russ_sal_all{k}(:)),[12 NaN]);
    Poho_sal = imresize(Poho_sal_all{k},[12 NaN]);
    subplot(141)
    imshow(f); title(k); 
    subplot(142);
    imagesc(russ_sal);title('Russell Sal');axis off; colormap('copper');
    subplot(143)
    imagesc(Poho_sal - russ_sal); title('Poho-Russ');axis off; colormap('copper');
    subplot(144);
    imagesc(Poho_sal); title('POHO');axis off; colormap('copper');
    
    pause;
end

%%
%load both of these to generate the figure
%load('Poho_output_K1_hardsalimages_Rad.mat')
%load('16396fd1-8e1c-4e47-afdd-88d28956fbe4.mat')
figure(1)
k=10;
f = ['~/Dropbox/hard-salience-images/' num2str(k) '_resize.jpg'];
russ_sal = downsize_map(russ_sal_all{k}/sum(russ_sal_all{k}(:)),64);
Poho_sal = downsize_map(Poho_sal_all{k},64);
deepgaze = downsize_map(exp(log_density),64);
subplot(141)
imshow(f); title('Example Input'); 
subplot(142)
imagesc(deepgaze); title('K{\"u}mmerer et al. (2016)');axis off; colormap('gray');
subplot(143);
imagesc(russ_sal);title('Russell et al. (2014)');axis off; colormap('gray');
subplot(144);
imagesc(Poho_sal); title('POHO');axis off; colormap('gray');

% pause;

function [X,Y,R,Str] = ProtoThresh2(gPyr)
%ProtoThresh finds proto-objects in an image based on grouping cell
%activies.
%   [X,Y,R,str] = ProtoThresh(gPyr) takes in a grouping cell pyramid and
%   finds the locations (X,Y) of the peaks in activation, as well as the
%   associated grouping cell radii (R) and the strength of their activation
%   (str).

imsize = size(gPyr{1}.subtype{1}(1).data);

disp('Finding peak grouping activity');
X = []; Y = []; R = []; Str = [];
for ty = 1:length(gPyr)
	typePyr = gPyr{ty};
    disp(typePyr.type);
    for subty = 1:length(typePyr.subtype)
        subPyr = typePyr.subtype{subty};
        
        for ll = 1:length(subPyr);
            %(no more peak finding or thresholding) find peaks in gcell pyramid
            levdat = subPyr(ll).data;
%             imagesc(levdat);colormap('gray');
%             step = size(subPyr(1).data,2)/size(levdat,2);
            r_this = subPyr(ll).R;
            
            [x,y] = meshgrid(linspace(1,size(subPyr(1).data,2),size(levdat,2)),linspace(1,size(subPyr(1).data,1),size(levdat,1)));
            %threshold peaks below a certain strength
            str = r_this^2*levdat;
            x = x(:); y = y(:); 
            str = str(:);

%             high_enough = str>max(str)/10;
            
            %find and save X,Y,R, and strength of peaks
%             x = x(high_enough);
%             y = y(high_enough);
%             str = str(high_enough);
            r = r_this*ones(size(str));
            
            X = [X; x]; Y = [Y; y]; % +1 because ctr had a row/column cut off
            R = [R; r]; Str = [Str; str]; 
            
%             pause;
        end
        
    end
end


end




function ind = getCircInd( x,y,r,siz )
%GETCIRCIND gets the indicies of an image that are inside a circle
%   ind = getCircInd(x,y,r,siz) gives the indicies of an image of size siz,
%   inside a circle centered at (x,y) with radius r.

[X, Y] = meshgrid(1:siz(2), 1:siz(1));
ind = find((X-x).^2 + (Y-y).^2<r^2);

end


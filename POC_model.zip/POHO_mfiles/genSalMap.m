function [ salMap ] = genSalMap( X,Y,R, str, imsiz )
%genSalMap Creates a saliency map out of a set of proto objects and
%strengths
%   Detailed explanation goes here

    if any([length(X)~=length(Y) length(X)~=length(R) length(X) ~=length(str)])
       error('Should be an equal number of positions, radii, and salience values');
    end
    imsiz = imsiz(1:2);
    salMap = zeros(imsiz);

%     for p = 1:length(X);
%         inx = getCircInd(X(p),Y(p),R(p),imsiz);
%         salMap(inx) = salMap(inx) + str(p);
%     end
    R_list = unique(R);
    for rind = 1:length(R_list);
        r = R_list(rind);
        tmp = accumarray([round(Y(R==r)) round(X(R==r))],str(R==r),imsiz);
        h = fspecial('gaussian', 4*r+1,r/2);
        h = h/max(h(:));
        tmp = imfilter(tmp,h);
        salMap = salMap+tmp;
    end

end


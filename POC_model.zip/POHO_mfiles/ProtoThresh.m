function [X,Y,R,Str] = ProtoThresh(gPyr)
%ProtoThresh finds proto-objects in an image based on grouping cell
%activies.
%   [X,Y,R,str] = ProtoThresh(gPyr) takes in a grouping cell pyramid and
%   finds the locations (X,Y) of the peaks in activation, as well as the
%   associated grouping cell radii (R) and the strength of their activation
%   (str).

imsize = size(gPyr{1}.subtype{1}(1).data);

disp('Finding peak grouping activity');
X = []; Y = []; R = []; Str = [];
for ty = 1:length(gPyr)
	typePyr = gPyr{ty};
    disp(typePyr.type);
    for subty = 1:length(typePyr.subtype)
        subPyr = typePyr.subtype{subty};
        
        for ll = 3:length(subPyr);
            %find peaks in gcell pyramid
            levdat = subPyr(ll).data;
%             imagesc(levdat);colormap('gray');
            
            r_this = subPyr(ll).R;
            levdat = imresize(levdat,imsize);
            ctr = levdat(2:end-1,2:end-1); %pick out non-border elements (will have issues if peaks are on the edges)
            ispeak = ctr >levdat(1:end-2,2:end-1) & ctr >levdat(3:end,2:end-1) & ctr >levdat(2:end-1,1:end-2) & ctr >levdat(2:end-1,3:end);
            
            %threshold peaks below a certain strength
            str = r_this^2*ctr(ispeak);
%             high_enough = str>max(str)/10;
            
            %find and save X,Y,R, and strength of peaks
            [y, x] = find(ispeak);
%             x = x(high_enough);
%             y = y(high_enough);
%             str = str(high_enough);
            r = r_this*ones(size(str));
            
            X = [X; x+1]; Y = [Y; y+1]; % +1 because ctr had a row/column cut off
            R = [R; r]; Str = [Str; str]; 
            
            figure(2);
%             subplot(121);
%             imagesc(levdat);colormap('gray');
            hold all;vl_plotframe([x/2^(ll-1),y/2^(ll-1),r/2^(ll-1)]'); hold off;
%             subplot(122);
%             plot(log10(abs(str)))

            pause;
        end
        
    end
end


end


function [ Q ] = Competition( P,K,alpha )
%COMPETITION applies competition between proto-objects
%   For each bin of each feature, a competition function is applied Q =
%   P/sum(P), so that N proto-objects of the same strength will be given
%   1/N weighting.

    siz = size(P);
    Nbins = siz(1);Nfeat = siz(2); %Nproto = siz(3);
    
    Q = zeros(size(P));
    
    for bin = 1:Nbins
        for feat = 1:Nfeat
            tmp = squeeze(P(bin,feat,:));
%             if feat ==1
%                 disp(safeDivide(sum(tmp),max(tmp)));
%             end
            tmp = safeDivide(tmp,sum(tmp)^K);
            Q(bin,feat,:) = tmp;
        end
    end
    
     Q = (1-alpha)*Q+alpha*P;
end


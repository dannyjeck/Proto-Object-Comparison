function [ out ] = HigherFeat(X,Y,R,str,im,N)
%HIGHERFEAT Summary of this function goes here
%   Detailed explanation goes here

Nfeat = 4;
if nargin<1
    out = Nfeat;
    return;
end

imsiz = size(im);
%% histogram of pixel values
Rinx = log2(R);
Rad_out = zeros(N,1);
Rad_out(Rinx) = 1;

bins = linspace(0,100,N);
Rim = im(:,:,1);
Red_vals = Rim(getCircInd(X,Y,R,imsiz(1:2)));
c = hist(Red_vals,bins);
Red_out = c(:)/sum(c(:));

bins = linspace(-128,128,N);
Gim = im(:,:,2);
G_vals = Gim(getCircInd(X,Y,R,imsiz(1:2)));
[c] = hist(G_vals,bins);
G_out = c(:)/sum(c(:));

Bim = im(:,:,3);
B_vals = Bim(getCircInd(X,Y,R,imsiz(1:2)));
[c] = hist(B_vals,bins);
B_out = c(:)/sum(c(:));

%% output
out = str*[Rad_out Red_out G_out B_out];


end

